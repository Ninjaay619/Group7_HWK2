package com.example.group7_hwk2
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class OrderFragment : Fragment() {
    companion object {
        fun newInstance(drinkName: String, iceLevel: String, sugarLevel: String): OrderFragment {
            val fragment = OrderFragment()
            val args = Bundle().apply {
                putString("DRINK_NAME", drinkName)
                putString("ICE_LEVEL", iceLevel)
                putString("SUGAR_LEVEL", sugarLevel)
            }
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_order, container, false)

        val drinkName = arguments?.getString("DRINK_NAME") ?: ""
        val iceLevel = arguments?.getString("ICE_LEVEL") ?: ""
        val sugarLevel = arguments?.getString("SUGAR_LEVEL") ?: ""

        view.findViewById<TextView>(R.id.orderSummaryTextView)?.text =
            "您的訂單：\n飲料名稱：$drinkName\n冰塊：$iceLevel\n甜度：$sugarLevel"

        return view
    }
}