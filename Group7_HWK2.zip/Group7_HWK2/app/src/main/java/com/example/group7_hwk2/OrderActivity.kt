package com.example.group7_hwk2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class OrderActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_order_activity)

        val drinkName = intent.getStringExtra("DRINK_NAME") ?: ""
        val iceLevel = intent.getStringExtra("ICE_LEVEL") ?: ""
        val sugarLevel = intent.getStringExtra("SUGAR_LEVEL") ?: ""

        val fragment = OrderFragment.newInstance(drinkName, iceLevel, sugarLevel)
        supportFragmentManager.beginTransaction()
            .replace(R.id.orderSummaryTextView, fragment)
            .commit()
    }
}