package com.example.group7_hwk2
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val drinkNameEditText = findViewById<EditText>(R.id.drinkNameEditText)
        val iceRadioGroup = findViewById<RadioGroup>(R.id.iceRadioGroup)
        val sugarRadioGroup = findViewById<RadioGroup>(R.id.sugarRadioGroup)
        val submitButton = findViewById<Button>(R.id.submitButton)

        submitButton.setOnClickListener {
            val drinkName = drinkNameEditText.text.toString()
            if (drinkName.isEmpty()) {
                Toast.makeText(this, "請輸入飲料名稱", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val iceLevel = when (iceRadioGroup.checkedRadioButtonId) {
                R.id.normalIce -> "正常冰"
                R.id.lessIce -> "少冰"
                R.id.lightIce -> "微冰"
                R.id.noIce -> "去冰"
                else -> "正常冰"
            }

            val sugarLevel = when (sugarRadioGroup.checkedRadioButtonId) {
                R.id.fullSugar -> "全糖"
                R.id.halfSugar -> "半糖"
                R.id.lightSugar -> "微糖"
                R.id.noSugar -> "無糖"
                else -> "全糖"
            }

            val orderSummary = "訂單確認：$drinkName\n冰塊：$iceLevel\n甜度：$sugarLevel"
            Toast.makeText(this, orderSummary, Toast.LENGTH_LONG).show()

            // 傳輸資料到OrderActivity
            val intent = Intent(this, OrderActivity::class.java).apply {
                putExtra("DRINK_NAME", drinkName)
                putExtra("ICE_LEVEL", iceLevel)
                putExtra("SUGAR_LEVEL", sugarLevel)
            }
            startActivity(intent)
        }
    }
}